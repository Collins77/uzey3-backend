const { default: axios } = require("axios");
const moment = require("moment");
const Payment = require("../models/Payment");

const MPESA_BASE_URL = "https://sandbox.safaricom.co.ke"; // Use sandbox for testing
// const MPESA_BASE_URL = "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest"; // Use sandbox for testing
const MPESA_CONSUMER_KEY = process.env.MPESA_CONSUMER_KEY;
const MPESA_CONSUMER_SECRET = process.env.MPESA_CONSUMER_SECRET;
const MPESA_SHORT_CODE = process.env.MPESA_SHORT_CODE;
const MPESA_PASSKEY = process.env.MPESA_PASSKEY;
const CALLBACK_URL = process.env.MPESA_CALLBACK_URL;



// const accessTokenGenerate = (req, res) => {
//     getAccessToken().then((accessToken) => {
//         res.send("Your access token is " + accessToken);
//     }).catch(console.log);
// };

// const stkPush = (req, res) => {
//     getAccessToken().then((accessToken) => {
//         const url = "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest",
//         auth = "Bearer " + accessToken;
//         var timestamp = moment().format("YYYYMMDDHHmmss");
//         const password = new Buffer.from("174379" + "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919" + timestamp).toString("base64");
//         request(
//             {
//                 url: url,
//                 method: "POST",
//                 headers: {
//                     Authorization: auth,
//                 },
//                 json: {
//                     BusinessShortCode: "174379",
//                     password: password,
//                     Timestamp: timestamp,
//                     TransactionType: "CustomerPayBillOnline",
//                     Amount: "1",
//                     PartyA: "254791448827",
//                     PartyB: "174379",
//                     PhoneNumber: "254791448827",
//                     CallBackURL: "https://d5a7-196-200-39-77.ngrok-free.app/api/payments/callback",
//                     AccountReference: "UZIMA PAY",
//                     TransactionDesc: "mpesa test",
//                 },
//             },
//             function (error, response, body) {
//                 if (error) {
//                     console.log(error);
//                 } else {
//                     console.log("Request is successful. Please enter Mpesa pin to complete the transaction");
//                     res.status(200).json(body);
//                 }
//             }
//         )
//     })
// }

// function getAccessToken() {
//     const consumer_key = `${MPESA_CONSUMER_KEY}`;
//     const consumer_secret = `${MPESA_CONSUMER_SECRET}`;
//     const url = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials";
//     const auth = "Basic " + new Buffer.from(consumer_key + ":" + consumer_secret).toString("base64");
//     return new Promise((response, request, reject) => {
//         request(
//             {
//                 url: url,
//                 headers: {
//                     Authorization: auth,
//                 },
//             },
//             function (error, res, body) {
//                 var jsonBody = JSON.parse(body);
//                 if (error) {
//                     reject(error);
//                 } else {
//                     const accessToken = jsonBody.access_token;
//                     response(accessToken);
//                 }
//             }
//         );
//     });
// }

// const callBack = (req, res) => {
//     const callBackData = req.body;
//     console.log(callBackData);
// }

const getAccessToken = async () => {
    try {
      const auth = Buffer.from(`${MPESA_CONSUMER_KEY}:${MPESA_CONSUMER_SECRET}`).toString("base64");
      const response = await axios.get("https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials", {
        headers: {
          Authorization: `Basic ${auth}`,
        },
      });
      return response.data.access_token;
    } catch (error) {
      console.error("Error fetching access token:", error.message);
      throw new Error("Failed to generate access token.");
    }
  };

const stkPush = async (req, res) => {
    try {
      const accessToken = await getAccessToken();
      const timestamp = moment().format("YYYYMMDDHHmmss");
      const password = new Buffer.from("174379" + "bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919" + timestamp).toString("base64");
  
      const stkResponse = await axios.post(
        "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest",
        {
            BusinessShortCode: "174379",
            Password: password,
            Timestamp: timestamp,
            TransactionType: "CustomerPayBillOnline",
            Amount: "1",
            PartyA: "254791448827",
            PartyB: "174379",
            PhoneNumber: "254791448827",
            CallBackURL: "https://uzey.api.kaboii.com/api/payments/callback",
            AccountReference: "UZIMA PAY",
            TransactionDesc: "mpesa test",
        },
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        }
      );
  
      res.status(200).json(stkResponse.data);
    } catch (error) {
    //   console.error("Error initiating STK push:", error.message);
      console.error("STK Push Error Response:", error.response?.data || error.message);

      res.status(500).json({ error: "Failed to process STK Push request" });
    }
  };
  
  // Callback function for MPesa
  const callBack = (req, res) => {
    console.log("Wameniita")
    try {
        const callbackData = req.body;
        // console.log("Callback Data:", callbackData);
        if (!callbackData.Body.stkCallback.CallbackMetadata) {
            console.log(callbackData.Body);
            return res.json("ok");
        }

        console.log(callbackData.Body.stkCallback.CallbackMetadata);

        const phone = callbackData.Body.stkCallback.CallbackMetadata.Item[3].Value
        const amount = callbackData.Body.stkCallback.CallbackMetadata.Item[0].Value
        const trnx_id = callbackData.Body.stkCallback.CallbackMetadata.Item[1].Value

        const payment = new Payment();
        payment.number = phone;
        payment.amount = amount;
        payment.trnx_id = trnx_id;

        payment.save().then((data) => {
            console.log({message: "saved successfully", data});
        }).catch((err) => {
            console.log(err.message);
        });
        // res.status(200).json({ message: "Callback received successfully" });
    } catch (error) {
        console.error("Error parsing callback data:", error.message);
        res.status(400).json({ error: "Invalid callback data" });
    }
  };

module.exports = {getAccessToken, stkPush, callBack}